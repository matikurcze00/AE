clear all;
load('skrypt_workspace.mat');

len = length(y);
[x_pos, x_neg] = x_labels(x,y);

% wybranie wersji
zadanie = 0;
if zadanie == 0
    % pozioma
    w = [0,1];
    b = 0;
elseif zadanie == 1
    % pionowa
    w = [1,0.00001];
    b = 0;
elseif zadanie == 2
    %45 stopni
    w = [1,1];
    b = 0;
elseif zadanie == 3
    %-45 stopni
    w = [-1,1];
    b = 0;
end
%parametry
eta = 0.8;
orth_w = [-w(2),w(1)];
a1 = (orth_w(2)/orth_w(1));
r = calc_r(x);

error_counter = [];
w_tablica = [];
b_tablica = [];
licznik=0;

while walidacja(x,y,a1,b) >0
    licznik=licznik+1
    for i=1:len
        if walidacja(x,y,a1,b) == 0
            break
        end
        w_tablica = [w_tablica; w];
        b_tablica = [b_tablica; b];
        if sign(dot(w, x(i,:))-b) ~= y(i)
            w = w + eta*y(i)*x(i,:);
            b = b - eta*y(i)*r*r;
            orth_w = [-w(2),w(1)];
            a1 = (orth_w(2)/orth_w(1));
        end
        orth_w = [-w(2),w(1)];
        a1 = (orth_w(2)/orth_w(1));

        [pos_supv, neg_supv, m, m_width] = margin(x_pos, x_neg, a1, b);
        m_center = [pos_supv(1) + m(1)/2, pos_supv(2) + m(2)/2];
        
        if a1 >= 0
            b = b+point_to_line_dist(m_center, a1, b);
        else
            b = b-point_to_line_dist(m_center, a1, b);
        end

        a = walidacja(x,y,a1,b);
        error_counter = [error_counter; a];
    end
end

if length(w_tablica) == 0
    w_tablica = w
    b_tablica = b
    orth_w = [-w(2),w(1)];
    a1 = (orth_w(2)/orth_w(1));

    [pos_supv, neg_supv, m, m_width] = margin(x_pos, x_neg, a1, b);
    m_center = [pos_supv(1) + m(1)/2, pos_supv(2) + m(2)/2];
    
    if a1 >= 0
        b = b+point_to_line_dist(m_center, a1, b);
    else
        b = b-point_to_line_dist(m_center, a1, b);
    end
end

figure;
scatter(x_pos(:,1),x_pos(:,2), 'x');
hold on
scatter(x_neg(:,1),x_neg(:,2), 'o');

a1 = orth_w(2)/orth_w(1);
b1 = b;
f = @(x1) a1*x1 + b1;
fplot(f)
legend("klasa 1", "klasa -1", "granica")
title("Granica decyzyjna")
xlim([-4,3])
ylim([-2,3])

figure;
subplot(2,1,1)
stairs(w_tablica(:,1))
ylabel("w(1)")
xlabel("nr iteracji")
title("Zmiany parametru w1 w funkcji iteracji")

subplot(2,1,2)
stairs(w_tablica(:,2))
ylabel("w(2)")
xlabel("nr iteracji")
title("Zmiany parametru w2 w funkcji iteracji")

figure;
stairs(b_tablica)
xlabel("nr iteracji")
ylabel("b")
title("Zmiany parametru b w funkcji iteracji")

figure;
stairs(error_counter);
xlabel("nr iteracji")
ylabel("liczba b��d�w")
title("liczby b��d�w w funkcji iteracji")
