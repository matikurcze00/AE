function d = point_to_line_dist(x, a, b)
    d=abs(a*x(1)-x(2)+b)/sqrt(a.^2+1);
